<?php

echo "<h2>Student Details</h2>";

echo "<table border='1' cellpadding='10' cellspacing='0'>";
echo "<tr>";
echo "<th><b>Name</b></th>";
echo "<th><b>ID</b></th>";
echo "<th><b>Class</b></th>";
echo "<th><b>Subject</b></th>";
echo "</tr>";

echo "<tr>";
echo "<td>  Mohamed Abdirahman maxamud </td>";
echo "<td>C1210031</td>";
echo "<td>CA211</td>";
echo "<td>PHP AND MYSQL</td>";
echo "</tr>";
echo "</table><br><br>";

//1: Function to convert decimal to binary
function decimalToBinary($num) {
    if ($num == 0) return '0';
    $binary = '';
    while ($num > 0) {
        $binary = ($num % 2) . $binary;
        $num = (int)($num / 2);
    }
    return $binary;
}

// Function to convert decimal to octal
function decimalToOctal($num) {
    if ($num == 0) return '0';
    $octal = '';
    while ($num > 0) {
        $octal = ($num % 8) . $octal;
        $num = (int)($num / 8);
    }
    return $octal;
}

// Function to convert decimal to hexadecimal
function decimalToHexadecimal($num) {
    if ($num == 0) return '0';
    $hexChars = '0123456789ABCDEF';
    $hex = '';
    while ($num > 0) {
        $hex = $hexChars[$num % 16] . $hex;
        $num = (int)($num / 16);
    }
    return $hex;
}

// Example usage
$decimal = 29; // Example decimal number

echo "Decimal: $decimal<br>";
echo "Binary: " . decimalToBinary($decimal) . "<br>";
echo "Octal: " . decimalToOctal($decimal) . "<br>";
echo "Hexadecimal: " . decimalToHexadecimal($decimal);
echo "<br><br>";

// Function to convert binary to decimal
if (!function_exists('binaryToDecimal')) {
    function binaryToDecimal($binary) {
        $decimal = 0;
        $length = strlen($binary);
        
        for ($i = 0; $i < $length; $i++) {
            // Check if the character is '1'
            if ($binary[$length - $i - 1] === '1') {
                $decimal += pow(2, $i); 
            }
        }
        return $decimal;
    }
}

// Function to convert decimal to octal
if (!function_exists('decimalToOctal')) {
    function decimalToOctal($decimal) {
        if ($decimal == 0) return '0'; 
        $octal = '';
        while ($decimal > 0) {
            $octal = ($decimal % 8) . $octal; 
            $decimal = (int)($decimal / 8);
        }
        return $octal;
    }
}

// Function to convert decimal to hexadecimal
if (!function_exists('decimalToHexadecimal')) {
    function decimalToHexadecimal($decimal) {
        if ($decimal == 0) return '0'; 
        $hexChars = '0123456789ABCDEF';
        $hex = '';
        
        while ($decimal > 0) {
            $hex = $hexChars[$decimal % 16] . $hex;
            $decimal = (int)($decimal / 16);         
        }
        return $hex; 
    }
}

// Function to convert binary to octal
if (!function_exists('binaryToOctal')) {
    function binaryToOctal($binary) {
        $decimal = binaryToDecimal($binary);
        return decimalToOctal($decimal);
    }
}

// Function to convert binary to hexadecimal
if (!function_exists('binaryToHexadecimal')) {
    function binaryToHexadecimal($binary) {
        $decimal = binaryToDecimal($binary); 
        return decimalToHexadecimal($decimal); 
    }
}

// Example binary input
$binaryInput = '11111111'; // Example input

echo "Binary: $binaryInput<br>";
echo "Decimal: " . binaryToDecimal($binaryInput) . "<br>";
echo "Octal: " . binaryToOctal($binaryInput) . "<br>";
echo "Hexadecimal: " . binaryToHexadecimal($binaryInput);
echo "<br><br>";


// 3: Array Operations
$array = [5, -7, 12, 10, -7, 11, -6, 12, 1, -7, 2, 9];

// Print all elements
echo "Array elements: " . implode(", ", $array) . "<br><br>";

// Total of all elements
$total = array_sum($array);
echo "Total of all elements: $total<br><br>";

// Total of even elements
$evenTotal = array_sum(array_filter($array, fn($x) => $x % 2 === 0));
echo "Total of even elements: $evenTotal<br><br>";

// Total of odd elements
$oddTotal = array_sum(array_filter($array, fn($x) => $x % 2 !== 0));
echo "Total of odd elements: $oddTotal<br><br>";

// Minimum element and its positions
$min = min($array);
$minPositions = array_keys($array, $min);
echo "Minimum element: $min at positions: " . implode(", ", $minPositions) . "<br><br>";

// Maximum element and its positions
$max = max($array);
$maxPositions = array_keys($array, $max);
echo "Maximum element: $max at positions: " . implode(", ", $maxPositions) ;
echo"<br><br>";


// Associative Array for Light, Normal, and Dark Colors
$colors = [
    'Light' => ['Red' => 'Light Red', 'Green' => 'Light Green', 'Blue' => 'Light Blue'],
    'Normal' => ['Red' => 'Normal Red', 'Green' => 'Normal Green', 'Blue' => 'Normal Blue'],
    'Dark' => ['Red' => 'Dark Red', 'Green' => 'Dark Green', 'Blue' => 'Dark Blue']
];

// Output the colors in a table format
echo "<table border='1' cellpadding='10'>";
echo "<tr><th>Shade</th><th>Color</th><th>Value</th></tr>";

foreach ($colors as $shade => $colorValues) {
    foreach ($colorValues as $color => $value) {
        echo "<tr>";
        echo "<td>$shade</td>";
        echo "<td>$color</td>";
        echo "<td>$value</td>";
        echo "</tr>";
    }
}

echo "</table>";
echo "<br><br>";


// 2D Array Operations for a Square Array

$array = [
    [2, -6, 8],
    [-6, 1, 6],
    [7, 8, -6]
];

// Output the array elements in a table format
echo "<table border='1' cellpadding='10'>";
echo "<tr><th>Column 1</th><th>Column 2</th><th>Column 3</th></tr>";

foreach ($array as $row) {
    echo "<tr>";
    foreach ($row as $element) {
        echo "<td>$element</td>";
    }
    echo "</tr>";
}

echo "</table>";
echo "<br><br>";



// Associative Array for Students' Details
$students = [
    'CA202' => ['Name' => 'Amina Nur Adan', 'Phone' => '0646990276', 'Address' => 'Macmacaanka, Dharkeynley'],
    'CA207' => ['Name' => 'Ahmed Abdi Jama', 'Phone' => '0647223201', 'Address' => 'Taleex, Hodan']
    
];

// Output the students' details in a table format
echo "<table border='1' cellpadding='10'>";
echo "<tr><th>Student Code</th><th>Name</th><th>Phone</th><th>Address</th></tr>";

foreach ($students as $code => $details) {
    echo "<tr>";
    echo "<td>$code</td>";
    echo "<td>{$details['Name']}</td>";
    echo "<td>{$details['Phone']}</td>";
    echo "<td>{$details['Address']}</td>";
    echo "</tr>";
}

echo "</table>";
echo "<br><br>";



// Array for Student Transcript
$transcript = [
    'Semester 1' => [
        ['subject1', 9, 26, 10, 40, 85, 'Pass'],
        ['subject2', 9, 26, 10, 40, 85, 'Pass'],
        ['subject3', 9, 26, 10, 40, 85, 'Pass']
    ],
    'Semester 2' => [
        ['subject1', 9, 26, 10, 0, 45, 'Fail'],
        ['subject2', 9, 26, 10, 40, 85, 'Pass'],
        ['subject3', 9, 26, 10, 40, 85, 'Pass']
    ]
];

// Output the transcript in a table format for each semester
foreach ($transcript as $semester => $courses) {
    echo "<h3>$semester</h3>";
    echo "<table border='1' cellpadding='10'>";
    echo "<tr>
            <th>Subject</th>
            <th>Quiz</th>
            <th>Assignment</th>
            <th>Midterm</th>
            <th>Final</th>
            <th>Total</th>
            <th>Status</th>
          </tr>";

    foreach ($courses as $course) {
        echo "<tr>";
        foreach ($course as $detail) {
            echo "<td>$detail</td>";
        }
        echo "</tr>";
    }

    echo "</table>";
    echo "<br><br>";
}
?>