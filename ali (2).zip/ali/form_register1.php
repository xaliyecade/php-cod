<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form</title>
    <style>
        label {
            margin: 20px 10px;
        }
        input {
            padding: 8px;
        }
        select {
            padding: 8px 15px;
        }
    </style>
</head>
<body>
    
<h1>Student Registration</h1>

<form action="form_handling.php" method="get">
<fieldset>
<legend>Registration Form</legend>

<label for="">Name: </label>
<input type="text" name="name" placeholder="Enter your name" required> <br><br>
<label for="">Place of Birth: </label>
<input type="text" name="pob" placeholder="Enter your place of birth"> <br><br>
<label for="">Phone: </label>
<input type="number" name="phone" placeholder="Enter your phone"> <br><br>
<label for="">Gender: </label>
<input type="radio" name="gender" value="Male"> Male
<input type="radio" name="gender" value="Female"> Female <br><br>

<label for="">Faculty: </label>
<select name="faculty" id="">
    <option value="CIT">Computer & IT</option>
    <option value="EE">Engineering</option>
    <option value="MD">Medicine</option>
    <option value="ECOM">Economic</option>
</select><br><br>

<label for="">Hobbies:</label>
<input type="checkbox" name="hobbies[]" value="Reading"> Reading
<input type="checkbox" name="hobbies[]" value="Travelling"> Travelling
<input type="checkbox" name="hobbies[]" value="Exercise"> Exercise
<input type="checkbox" name="hobbies[]" value="Swimming"> Swimming
<input type="checkbox" name="hobbies[]" value="Movies"> Movies <br><br>

<label for="">Languages:</label>
<select name="languages[]" multiple size="5">
    <option>Somali</option>
    <option>English</option>
    <option>Arabic</option>
    <option>Spanish</option>
    <option>Turkish</option>
</select><br><br>

<label for="">Register Date:</label>
<input type="date" name="date"><br><br>

<input type="submit" name="submit" value="Register">
<input type="reset" name="reset" value="Clear">


</fieldset>
</form>

<h2>Student Information</h2>

<?php

if (!empty($_POST['submit'])) {

echo "<b>Name: </b>" . $_POST["name"] . "<br>";
echo "<b>Place of Birth: </b>" . $_POST["pob"] . "<br>";
echo "<b>Phone: </b>" . $_POST["phone"] . "<br>";

if (!empty($_POST["gender"]))
echo "<b>Gender: </b>" . $_POST["gender"] . "<br>";

echo "<b>Faculty: </b>" . $_POST["faculty"] . "<br>";

echo "<b>Hobbies: </b>" ;
if (!empty($_POST["gender"]))
foreach ($_POST["hobbies"] as $v) {
    echo "$v, ";
}
echo "<br>";

echo "<b>Languages: </b>" ;
if (!empty($_POST["gender"]))
foreach ($_POST["languages"] as $v) {
    echo "$v, ";
}
echo "<br>";

echo "<b>Register Date: </b>" . $_POST["date"] . "<br>";

}

?>


</body>
</html>