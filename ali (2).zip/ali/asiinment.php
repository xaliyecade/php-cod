<!DOCTYPE html>
<html>
<head>
    <style>
        .div3 { background-color: blue; }
        .div5 { background-color: green; }
        .divBoth { background-color: orange; }
    </style>
</head>
<body>
    <table border="1" cellpadding="10">
        <?php
        $count = 1;
        for ($i = 1; $i <= 10; $i++) {
            echo "<tr>";
            for ($j = 1; $j <= 10; $j++) {
                $class = '';
                if ($count % 3 == 0 && $count % 5 == 0) {
                    $class = 'divBoth';
                } elseif ($count % 3 == 0) {
                    $class = 'div3';
                } elseif ($count % 5 == 0) {
                    $class = 'div5';
                }
                echo "<td class='$class'>$count</td>";
                $count++;
            }
            echo "</tr>";
        }
        ?>
    </table>
</body>
</html>





<!DOCTYPE html>
<html>
<head>
    <style>
        .prime { background-color: yellow; font-weight: bold; }
    </style>
</head>
<body>
    <div>
        <?php
        function isPrime($num) {
            if ($num < 2) return false;
            for ($i = 2; $i <= sqrt($num); $i++) {
                if ($num % $i == 0) return false;
            }
            return true;
        }

        for ($i = 1; $i <= 50; $i++) {
            $class = isPrime($i) ? 'prime' : '';
            echo "<span class='$class'>$i </span>";
        }
        ?>
    </div>
</body>
</html>




<!DOCTYPE html>
<html>
<head>
    <style>
        .odd { background-color: yellow; }
        .even { background-color: green; }
        .square { background-color: blue; }
    </style>
</head>
<body>
    <table border="1" cellpadding="10">
        <?php
        for ($i = 1; $i <= 100; $i++) {
            $class = '';
            if ($i % 2 == 0) {
                $class = 'even';
            } else {
                $class = 'odd';
            }

            // Check if the number is a perfect square
            if (sqrt($i) == floor(sqrt($i))) {
                $class = 'square';
            }

            echo ($i % 10 == 1) ? "<tr>" : ""; // New row every 10 numbers
            echo "<td class='$class'>$i</td>";
            echo ($i % 10 == 0) ? "</tr><br>" : ""; // Close the row every 10 numbers with a break
        }
        ?>
    </table>
</body>
</html>
