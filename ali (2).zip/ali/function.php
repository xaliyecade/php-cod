<?php

function WelcomeMsg($name) {
    echo "Hi $name, Welcome to the Faculty of Computer and IT";
}

WelcomeMsg("Mohamed");
echo "<br>";
$n = "Abdi";
WelcomeMsg($n);
echo "<br>";

function add ($n1, $n2) {
    $result = $n1 + $n2;
    echo "The sum of two numbers is ", $result;
}

add(5,4);

echo "<br>";

function factorial ($x) {
    $result = 1;

    for ($i=1; $i <= $x; $i++)
        $result *= $i;

    return "The Facorial of $x = " . $result;

}


echo factorial(5);
echo "<br>";
$n = 6;
$r = factorial($n);

echo $r;
echo "<br>";

$array1 = array(9,2,7,5,3);

function PassArray ($arr) {

    echo "The Passed array : ";

    for($i = 0; $i < count($arr); $i++) {
        echo "$arr[$i], ";
        $arr[$i]++;
    }

    echo "<br>";

    return $arr;
}

$a = PassArray($array1);

echo "The returned Array is: ";

foreach($a as $v) {
    echo "$v, ";
}

// By Value and By Reference

$n = 5;

function byvalue($a) {
    echo "The Passed Value: " . $a . "<br>";
    $a++;
    echo "The Current Value: " . $a . "<br>";
}

echo "<br>";
byvalue($n);
echo "The Value of N: " . $n . "<br>";

function byreference(&$a) {
    echo "The Passed Value: " . $a . "<br>";
    $a++;
    echo "The Current Value: " . $a . "<br>";
}

byreference($n);
echo "The Value of N: " . $n . "<br>";

// Default Argument

function sum($x = 5, $y = 3) {
    $total = $x + $y;
    echo "The Total of two numbers: " . $total . "<br>";
}

sum(3, 6);
sum(7);
sum();

// Variable Scope

$age = 20;

function scope() {
    $name = "Mohamed";
    global $address;
    $address = "Hodan";
    echo "Local Variable with in the function: " . $name . "<br>";
    echo "Global Variable with in the function: " . $GLOBALS['age'] . "<br>";
    
}

scope();
echo "Local Variable Outside the function: " . $address . "<br>";

function counter() {
    static $count = 1;
    $count++;
    echo "The counter value " . $count . "<br>";
}

counter();
counter();
counter();
counter();

?>