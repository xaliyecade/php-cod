<?php
function findGreatestAndSmallest($a, $b, $c) {
    $greatest = $a;  // Start by assuming the first number is both the greatest and smallest
    $smallest = $a;

    if ($b > $greatest) {  // If the second number is bigger, it's the greatest
        $greatest = $b;
    }
    if ($c > $greatest) {  // Same for the third number
        $greatest = $c;
    }

    if ($b < $smallest) {  // Check if the second number is smaller
        $smallest = $b;
    }
    if ($c < $smallest) {  // And the third
        $smallest = $c;
    }

    echo "Greatest: $greatest\n";
    echo "Smallest: $smallest\n";
}

findGreatestAndSmallest(15, 8, 25);  // Try this out with a few numbers
?>


<?php
function checkDivisibility($num) {
    if ($num % 3 == 0 && $num % 5 == 0) {  // Divisible by both? Nice!
        echo "$num is divisible by both 3 and 5\n";
    } elseif ($num % 3 == 0) {
        echo "$num is divisible by 3\n";
    } elseif ($num % 5 == 0) {
        echo "$num is divisible by 5\n";
    } else {
        echo "$num is divisible by neither 3 nor 5\n";
    }
}

checkDivisibility(15);  // Check how 15 fares
?>


<?php
// Print odd numbers from 2 to 20
echo "Odd numbers from 2 to 20:\n";
for ($i = 2; $i <= 20; $i++) {
    if ($i % 2 != 0) {
        echo "$i ";  // Look at that! Odd numbers in action
    }
}
echo "\n";

// Print even numbers backward from 35 to 7
echo "Even numbers from 35 to 7:\n";
for ($i = 35; $i >= 7; $i--) {
    if ($i % 2 == 0) {
        echo "$i ";  // Backward fun!
    }
}
echo "\n";
?>



<?php
echo "Numbers divisible by 2 and 5 from 50 to 2:\n";
for ($i = 50; $i >= 2; $i--) {
    if ($i % 2 == 0 && $i % 5 == 0) {
        echo "$i ";  // Two and five, the dynamic duo
    }
}
echo "\n";
?>


<?php
function reverseNumber($num) {
    $reverse = 0;
    while ($num > 0) {
        $reverse = $reverse * 10 + $num % 10;
        $num = (int)($num / 10);  // Chop off the last digit
    }
    return $reverse;
}

echo "Reversed: " . reverseNumber(12345) . "\n";  // See how 54321 looks
?>



<?php
function findLCM($a, $b) {
    $max = ($a > $b) ? $a : $b;  // Start with the larger number
    
    while (true) {
        if ($max % $a == 0 && $max % $b == 0) {
            return $max;  // Found the LCM
        }
        $max++;  // Increment and check again
    }
}

echo "LCM of 8 and 12 is: " . findLCM(8, 12) . "\n";
?>



<?php
function findHCF($a, $b) {
    while ($b != 0) {
        $temp = $b;
        $b = $a % $b;
        $a = $temp;
    }
    return $a;
}




echo "HCF of 18 and 24 is: " . findHCF(18, 24) . "\n";
?>

<?php
echo "<table border='1' cellpadding='5'>";
for ($i = 1; $i <= 12; $i++) {
    echo "<tr>";
    for ($j = 1; $j <= 12; $j++) {
        echo "<td>" . $i * $j . "</td>";
    }
    echo "</tr>";
}
echo "</table>";
?>



<?php
function isPrime($num) {
    if ($num <= 1) return false;
    for ($i = 2; $i <= sqrt($num); $i++) {
        if ($num % $i == 0) return false;  // Not a prime if divisible by i
    }
    return true;
}

echo "17 is " . (isPrime(17) ? "a prime number\n" : "not a prime number\n");  // Check if 17 is prime
?>



<?php
echo "Prime numbers from 10 to 50:\n";
for ($i = 10; $i <= 50; $i++) {
    if (isPrime($i)) {
        echo "$i ";  // The elite list of primes!
    }
}
echo "\n";
?>
