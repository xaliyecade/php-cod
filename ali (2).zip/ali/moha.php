<?php 
$daysofweak=date(6);
switch($daysofweak){
    case 1:
        echo"saturday.";
        break;
        case 2:
            echo"sunday";
            break;
            case 3:
                echo"monday";
                break;
                case 4:
                    echo"tuesday";
                    break;
                    case 5:
                        echo"wensday";
                        break;
                        case 6;
                        echo"thusday";
                        break;
                        case 7;
                        echo"friday";
                        break;
                        default:
                        echo"invalid";
                        break;
}
echo '<br>';
echo '<br>';

?>
<?php 

$number = 7;
echo ($number % 2 == 0) ? "$number is an even num." : "$number is an odd num.";
echo '<br>';
echo '<br>'

?>

<?php
echo '<br>';
for ($i = 1; $i <= 9; $i++) {
  for ($j = 1; $j <= 9; $j++) {
        echo "$i x $j = " . ($i * $j) . "\t";
    }
    
    echo "<br>";
}



echo '<br>';
echo '<br>';
echo '<br>';

?>
<?php
echo '<br>';
$purchaseAmount = 7000;
$discount = 50;

if ($purchaseAmount > 70000) {
    $discount = 70;
} elseif ($purchaseAmount >= 300 && $purchaseAmount <= 500) {
    $discount = 20;
} elseif ($purchaseAmount >= 100 && $purchaseAmount < 300) {
    $discount = 10;
} elseif ($purchaseAmount < 100) {
    $discount = 5;
}


$discountAmount = ($purchaseAmount * $discount) / 100;
$finalPrice = $purchaseAmount - $discountAmount;


echo "Purchase Amount: $$purchaseAmount";
echo '<br>';
echo "Discount: $discount%";
echo '<br>';
echo "Final Price: $$finalPrice\n";
?>

?>

