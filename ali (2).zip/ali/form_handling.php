<h2>Student Information</h2>

<?php

if (!empty($_GET['submit'])) {

echo "<b>Name: </b>" . $_GET["name"] . "<br>";
echo "<b>Place of Birth: </b>" . $_GET["pob"] . "<br>";
echo "<b>Phone: </b>" . $_GET["phone"] . "<br>";

if (!empty($_GET["gender"]))
echo "<b>Gender: </b>" . $_GET["gender"] . "<br>";

echo "<b>Faculty: </b>" . $_GET["faculty"] . "<br>";

echo "<b>Hobbies: </b>" ;
if (!empty($_GET["gender"]))
foreach ($_GET["hobbies"] as $v) {
    echo "$v, ";
}
echo "<br>";

echo "<b>Languages: </b>" ;
if (!empty($_GET["gender"]))
foreach ($_GET["languages"] as $v) {
    echo "$v, ";
}
echo "<br>";

echo "<b>Register Date: </b>" . $_GET["date"] . "<br>";

}

?>
