<?php
$countries = [
    "Somalia" => ["capital" => "Mogadishu"],
    "Kenya" => ["capital" => "Nairobi"],
    "Ethiopia" => ["capital" => "Addis Ababa"],
    "Uganda" => ["capital" => "Kampala"]
];

function getCapital($countryName) {
    global $countries; 
    return isset($countries[$countryName]) ? $countries[$countryName]["capital"] : "Capital not found";
}

echo "Countries and their Capitals:<br>";
foreach ($countries as $country => $info) {
    echo "Country: $country, Capital: " . $info["capital"] . "<br>";
}

echo "<br>";

echo "Capital of Kenya: " . getCapital("Kenya") . "<br>";
echo "Capital of Uganda: " . getCapital("Uganda") . "<br>";

echo "<br>";

$numbers = [5, 10, 15, 20, 25];
function sumArray($arr) {
    $sum = 0;
    foreach ($arr as $num) {
        $sum += $num;
    }
    return $sum;
}

echo "Sum of numbers: " . sumArray($numbers) . "<br>";

echo "<br>";


$studentTranscript = [
    [
        "Semester" => "Semester 1",
        "Course" => "Python",
        "CW1" => 10,
        "Midterm" => 25,
        "CW2" => 10,
        "Final" => 40
    ],
    [
        "Semester" => "Semester 1",
        "Course" => "JavaScript",
        "CW1" => 9,
        "Midterm" => 25,
        "CW2" => 10,
        "Final" => 40
    ],
    [
        "Semester" => "Semester 1",
        "Course" => "Oracle",
        "CW1" => 9,
        "Midterm" => 45,
        "CW2" => 10,
        "Final" => 20
    ],
    [
        "Semester" => "Semester 2",
        "Course" => "Networking",
        "CW1" => 4,
        "Midterm" => 15,
        "CW2" => 6,
        "Final" => 15
    ],
    [
        "Semester" => "Semester 2",
        "Course" => "Flutter",
        "CW1" => 9,
        "Midterm" => 25,
        "CW2" => 10,
        "Final" => 40
    ],
    [
        "Semester" => "Semester 2",
        "Course" => "PHP",
        "CW1" => 9,
        "Midterm" => 25,
        "CW2" => 10,
        "Final" => 40
    ]
];

foreach ($studentTranscript as &$record) {
    $record["Total"] = $record["CW1"] + $record["Midterm"] + $record["CW2"] + $record["Final"];
    $record["Status"] = $record["Total"] >= 50 ? "Pass" : "Fail";
}

echo "<table border='1' cellspacing='0' cellpadding='10'>";
echo "<tr style='font-weight:bold; background-color:black; color:white;'>
        <td>Semester</td><td>Course</td><td>CW1</td><td>Midterm</td><td>CW2</td><td>Final</td><td>Total</td><td>Status</td>
      </tr>";

$semesterCount = ["Semester 1" => 3, "Semester 2" => 3];
$displayedSemester = [];

foreach ($studentTranscript as $record) {
    $rowBgColor = "white"; 
    if ($record["Course"] == "Oracle") {
        $rowBgColor = "yellow";
    } elseif ($record["Course"] == "Networking") {
        $rowBgColor = "red";
    }

    echo "<tr style='background-color:$rowBgColor;'>";

    if (!in_array($record["Semester"], $displayedSemester)) {
        echo "<td rowspan='{$semesterCount[$record["Semester"]]}' style='background-color:black; color:white;'>{$record["Semester"]}</td>";
        $displayedSemester[] = $record["Semester"];
    }

    echo "<td>{$record["Course"]}</td>
          <td>{$record["CW1"]}</td>
          <td>{$record["Midterm"]}</td>
          <td>{$record["CW2"]}</td>
          <td>{$record["Final"]}</td>
          <td>{$record["Total"]}</td>
          <td>{$record["Status"]}</td>
          </tr>";
}
echo "</table>";
?>