<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assignment Practice Code</title>
    <style>
        /* Table styling */
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center;
        }
        th {
            background-color: #f2f2f2;
        }
        /* Color coding for marks */
        .warning {
            color: yellow;
        }
        .danger {
            color: red;
        }
    </style>
</head>
<body>

<h1>Countries and Capitals</h1>
<?php
// Part 1: Countries and Capitals

// Multidimensional associative array for countries and capitals
$countries = [
    "USA" => "Washington, D.C.",
    "Canada" => "Ottawa",
    "UK" => "London",
    "Germany" => "Berlin",
    "France" => "Paris"
];

// Function to get the capital of a country
function getCapital($country) {
    global $countries;
    return $countries[$country] ?? "Capital not found";
}

// Display country and capital names
echo "<ul>";
foreach ($countries as $country => $capital) {
    echo "<li>The capital of $country is $capital.</li>";
}
echo "</ul>";

// Function to calculate sum of array elements
function sumArray($numbers) {
    return array_sum($numbers);
}

// Example usage of sumArray function
$numbers = [5, 10, 15, 20];
echo "<p>The sum of the array is: " . sumArray($numbers) . "</p>";
?>

<h1>Student Transcript</h1>
<?php
// Part 2: Student Transcript Array

// Array for student transcript
$transcript = [
    [
        "semester" => 1,
        "course" => "Python",
        "CW1" => 10,
        "MidTerm" => 25,
        "CW2" => 10,
        "Final" => 40
    ],
    [
        "semester" => 1,
        "course" => "JavaScript",
        "CW1" => 9,
        "MidTerm" => 28,
        "CW2" => 10,
        "Final" => 40
    ],
    [
        "semester" => 1,
        "course" => "Cisco",
        "CW1" => 9,
        "MidTerm" => 16,
        "CW2" => 10,
        "Final" => 20
    ],
    [
        "semester" => 2,
        "course" => "Flutter",
        "CW1" => 9,
        "MidTerm" => 20,
        "CW2" => 15,
        "Final" => 40
    ],
    [
        "semester" => 2,
        "course" => "PHP and MySQL",
        "CW1" => 15,
        "MidTerm" => 20,
        "CW2" => 10,
        "Final" => 40
    ]
];

// Function to calculate total and status
function calculateTotalAndStatus($marks) {
    $total = $marks["CW1"] + $marks["MidTerm"] + $marks["CW2"] + $marks["Final"];
    $status = $total >= 50 ? "Pass" : "Fail";
    return [$total, $status];
}

// Function to apply color coding to marks
function colorCode($mark) {
    if ($mark < 50) {
        return "<span class='danger'>$mark</span>";
    } elseif ($mark >= 50 && $mark <= 60) {
        return "<span class='warning'>$mark</span>";
    }
    return $mark;
}

// Display the transcript table
echo "<table>";
echo "<tr><th>Semester</th><th>Course</th><th>CW1</th><th>MidTerm</th><th>CW2</th><th>Final</th><th>Total</th><th>Status</th></tr>";

foreach ($transcript as $course) {
    list($total, $status) = calculateTotalAndStatus($course);

    echo "<tr>";
    echo "<td>{$course['semester']}</td>";
    echo "<td>{$course['course']}</td>";
    echo "<td>" . colorCode($course['CW1']) . "</td>";
    echo "<td>" . colorCode($course['MidTerm']) . "</td>";
    echo "<td>" . colorCode($course['CW2']) . "</td>";
    echo "<td>" . colorCode($course['Final']) . "</td>";
    echo "<td>$total</td>";
    echo "<td>$status</td>";
    echo "</tr>";
}

echo "</table>";
?>

</body>
</html>